module.exports = {
  TOKEN: 'c25d636aa39648b4ada8b06c0f1db90d'
};